// Field — 한 줄 입력. input group 이다: 래퍼가 면·테두리·포커스링·상태를 지고, 안쪽
// input 이 값을 담으며, 양옆에 어도먼트(아이콘·$·단위)와 액션(clear·비밀번호 보기)이 앉는다.
//   status   info · success · warning · error (테두리 색, 생략하면 중립). error 는 aria-invalid 도.
//   shape    rounded · pill — Button·Badge 와 같은 어휘. 검색창이 이 어휘의 본진이다.
//   numeric  포맷 축 — 숫자 글리프만 등폭(tabular-nums). 정렬은 안 건드린다. 래퍼가 달고 input 이 이어받는다.
//   textAlign 입력값의 글자 정렬 — start · center · end. numeric 과 직교 (우측정렬 숫자열은 numeric + textAlign="end").
//   leading  왼쪽 어도먼트 (검색 아이콘 · "$" 프리픽스 등)
//   trailing 오른쪽 어도먼트 (단위 "kg" · 아이콘 등)
//   clearable  값이 있으면 × 로 지우기 (controlled·uncontrolled 양쪽). 이름은 clearLabel.
//   showPasswordToggle  type="password" 일 때 👁 보기 토글을 켠다 (clearable 과 대칭인 opt-in). 이름은 showPasswordLabel.
//
// ref 는 안쪽 input 을 가리킨다. className·style·data-testid 는 래퍼(보이는 필드)로.
// 키보드 포커스는 useFocusRing 이 input 에서 판정하고, 링은 래퍼가 그린다.

import {
  forwardRef,
  useRef,
  useState,
  type CSSProperties,
  type InputHTMLAttributes,
  type ReactNode,
} from "react";

import { joinClass } from "../internal/joinClass";
import { useMessages } from "../internal/locale";
import { useMergedRef } from "../internal/refs";
import { Icon } from "../primitives/Icon";
import { Pressable } from "../primitives/press/Pressable";
import { Selectable } from "../primitives/select/Selectable";
import type { ControlForm } from "../primitives/control/Control";
import { fieldActionPaint, fieldAdornmentPaint, fieldPlaceholderPaint } from "../primitives/paint/recipes.css";
import { textNumericClass } from "../styles/typography.css";
import { inputFrameClass, useInputControl, type InputFrameProps } from "./input-control";
import { fieldWrap, fieldInput, fieldTextAlign, fieldAdornment, fieldAction, fieldActionReach } from "./Field.css";

export type FieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, "className" | "size" | "prefix"> & InputFrameProps & Pick<ControlForm, "shape" | "gap"> & {
  numeric?: boolean;
  // 입력값의 글자 정렬. 안쪽 요소의 세로 정렬인 Control 의 align 과 다른 축이라 이름을 나눴다.
  textAlign?: "start" | "center" | "end";
  leading?: ReactNode;
  trailing?: ReactNode;
  clearable?: boolean;
  // 지우기 버튼의 이름. 안 주면 PaperProvider 의 locale 이 고른 문구.
  clearLabel?: string;
  // type="password" 일 때 👁 보기 토글을 켠다 (clearable 과 대칭인 opt-in).
  showPasswordToggle?: boolean;
  // 보기 토글의 이름 — 눌림 여부는 aria-pressed 가 알리므로 이름은 늘 같다. 안 주면 locale 문구.
  showPasswordLabel?: string;
  onClear?: () => void;
  className?: string;
  style?: CSSProperties;
  "data-testid"?: string;
};

const XIcon = (
  <Icon aria-hidden>
    <path d="M6 6 18 18M18 6 6 18" />
  </Icon>
);
const EyeIcon = (
  <Icon aria-hidden>
    <path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12Z" />
    <circle cx="12" cy="12" r="2.75" />
  </Icon>
);
const EyeOffIcon = (
  <Icon aria-hidden>
    <path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12Z" />
    <circle cx="12" cy="12" r="2.75" />
    <path d="M3 3 21 21" />
  </Icon>
);

export const Field = forwardRef<HTMLInputElement, FieldProps>(function Field(
  {
    status,
    size,
    fill,
    variant,
    shadow,
    fontSize,
    shape,
    gap,
    numeric,
    textAlign,
    leading,
    trailing,
    clearable,
    clearLabel,
    showPasswordToggle,
    showPasswordLabel,
    onClear,
    type = "text",
    value,
    defaultValue,
    onChange,
    className,
    style,
    "data-testid": testid,
    ...rest
  },
  ref,
) {
  const messages = useMessages();
  const { inputProps, frameProps, isDisabled } = useInputControl(rest, { status, textInput: true });
  const input = useRef<HTMLInputElement>(null);
  const setRef = useMergedRef(ref, input);

  const [revealed, setRevealed] = useState(false);
  const isPassword = type === "password" && !!showPasswordToggle;
  const effectiveType = isPassword ? (revealed ? "text" : "password") : type;

  // clear 버튼 가시성 — controlled 면 value, 아니면 내부 추적.
  const [innerHasValue, setInnerHasValue] = useState(() => String(defaultValue ?? "").length > 0);
  const hasValue = value !== undefined ? String(value).length > 0 : innerHasValue;

  // 호출자가 먼저 — 내부 추적은 호출자가 남긴 값을 읽는다.
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange?.(e);
    if (value === undefined) setInnerHasValue(e.currentTarget.value.length > 0);
  };

  // native setter + input 이벤트로 controlled·uncontrolled 양쪽에서 onChange 를 발화시킨다.
  const clear = () => {
    const el = input.current;
    if (!el) return;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    setter?.call(el, "");
    el.dispatchEvent(new Event("input", { bubbles: true }));
    onClear?.();
    el.focus();
  };

  const showClear = !!clearable && hasValue && !isDisabled;
  const actionClass = joinClass(fieldAction, fieldActionPaint, fieldActionReach);

  return (
    // 래퍼는 위젯이 아니라 여백 클릭을 안쪽 input 으로 넘기는 표현용 컨테이너다 —
    // 진짜 컨트롤은 input 이라 role·키보드를 붙이는 게 오히려 틀리다.
    // eslint-disable-next-line jsx-a11y/no-static-element-interactions -- 여백 클릭만 안쪽 input 으로 넘긴다
    <span
      className={joinClass(inputFrameClass({ size, anatomy: "input", shape, fontSize, gap, fill, variant, shadow }), fieldWrap, numeric && textNumericClass, className)}
      style={style}
      data-testid={testid}
      {...frameProps}
      // 래퍼 여백을 클릭해도 input 이 포커스되게 (액션 버튼은 제외)
      onMouseDown={(e) => {
        const t = e.target as HTMLElement;
        if (t !== input.current && !t.closest("button")) {
          e.preventDefault();
          input.current?.focus();
        }
      }}
    >
      {leading ? <span className={joinClass(fieldAdornment, fieldAdornmentPaint)}>{leading}</span> : null}
        <input
          ref={setRef}
          type={effectiveType}
          value={value}
          defaultValue={defaultValue}
          onChange={handleChange}
          className={joinClass(fieldInput, fieldPlaceholderPaint, textAlign && fieldTextAlign[textAlign])}
          {...inputProps}
        />
        {showClear ? (
          <Pressable className={actionClass} onPress={clear} aria-label={clearLabel ?? messages.clear}>
            {XIcon}
          </Pressable>
        ) : null}
        {isPassword ? (
          <Pressable as={Selectable} className={actionClass} selected={revealed} onSelectedChange={setRevealed} disabled={isDisabled} aria-label={showPasswordLabel ?? messages.showPassword}>
            {revealed ? EyeOffIcon : EyeIcon}
          </Pressable>
        ) : null}
        {trailing ? <span className={joinClass(fieldAdornment, fieldAdornmentPaint)}>{trailing}</span> : null}
    </span>
  );
});
