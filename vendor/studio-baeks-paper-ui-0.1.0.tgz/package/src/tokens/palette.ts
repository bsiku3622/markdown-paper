// OKLCH palette source
//
// Palette identity and color anchors live here. Semantic roles, CSS names, and component
// vocabulary do not. This file assembles the completed palette by calling pure color-ladder
// operations, then exports both its OKLCH coordinates and generated HEX tokens.

import { completeOklchRamp, interpolateOklch, toPaletteToken, withAlpha } from "./color-ladder";
import type { PaletteToken } from "./color-ladder";
export type { PaletteToken } from "./color-ladder";

export const PALETTE_STEPS = ["0", "50", "100", "150", "200", "300", "400", "500", "600", "650", "700", "800", "875", "900", "925", "950"] as const;
export type PaletteStep = (typeof PALETTE_STEPS)[number];
export const ACCENT_STEPS = ["50", "100", "150", "200", "300", "400", "500", "600", "650", "700", "800", "900", "925", "950"] as const;
export type AccentStep = (typeof ACCENT_STEPS)[number];
export const ALPHA_STEPS = ["05", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55", "60", "65", "70", "75", "80", "85", "90", "95"] as const;
export type AlphaStep = (typeof ALPHA_STEPS)[number];
export const ALPHA_OPACITY: Record<AlphaStep, number> = {
  "05": 0.05, "10": 0.10, "15": 0.15, "20": 0.20, "25": 0.25, "30": 0.30, "35": 0.35,
  "40": 0.40, "45": 0.45, "50": 0.50, "55": 0.55, "60": 0.60, "65": 0.65, "70": 0.70,
  "75": 0.75, "80": 0.80, "85": 0.85, "90": 0.90, "95": 0.95,
};

export type Oklch = readonly [lightness: number, chroma: number, hue: number];
export const NEUTRAL_BASE_STEPS = ["0", "50", "100", "200", "300", "400", "500", "600", "700", "800", "900", "950"] as const;
export type NeutralBaseStep = (typeof NEUTRAL_BASE_STEPS)[number];

// Neutral step numbers always run from light to dark: 0 is white and 950 is near-black.
// The ramp is a zinc (2026-11-06, read from HeroUI v3's default theme): the ground is 0.9702 with no chroma, the grey face 0.94
// and the line 0.91, and the middle steps, where the quiet inks are, carry zinc's chroma so they read crisp, not muddy. A grey
// that is the same chroma all the way down (0.003 before) reads dull. 650 stays a step darker than HeroUI's muted ink, so a
// placeholder still holds 4.5:1 on the sunken face, which HeroUI's does not.
export const NEUTRAL_ANCHORS: Partial<Record<NeutralBaseStep, Oklch>> = {
  "0": [1, 0, 286],
  "100": [0.9702, 0, 286],
  "200": [0.91, 0.004, 286],
  "300": [0.88, 0.004, 286],
  "500": [0.66, 0.012, 286],
  "700": [0.47, 0.012, 286],
  "900": [0.28, 0.006, 286],
  "950": [0.18, 0.005, 286],
};

export const ACCENT_PALETTES = ["blue", "green", "amber", "red"] as const;
export type AccentPalette = (typeof ACCENT_PALETTES)[number];
// All accent families share perceptual lightness and a base chroma envelope.
// Hue-specific chroma ceilings preserve pigment identity within the sRGB gamut.
const ACCENT_CURVE: Record<AccentStep, readonly [lightness: number, chromaRatio: number]> = {
  "50": [0.985, 0.04], "100": [0.955, 0.16], "150": [0.930, 0.26],
  "200": [0.900, 0.38], "300": [0.800, 0.65], "400": [0.670, 0.80],
  "500": [0.610, 0.95], "600": [0.525, 1],
  "650": [0.4975, 0.95], "700": [0.470, 0.90],
  "800": [0.400, 0.75], "900": [0.330, 0.55], "925": [0.295, 0.475],
  "950": [0.260, 0.40],
};
// Each pigment is a hue and a chroma ceiling. Two refinements are data too: a pale end that starts at
// another hue and eases into the pigment's own between two steps, and steps whose chroma ratio
// replaces the shared curve's.
type AccentIdentity = {
  hue: number;
  chroma: number;
  paleHue?: { hue: number; from: AccentStep; to: AccentStep };
  chromaRatio?: Partial<Record<AccentStep, number>>;
};
export const ACCENT_IDENTITIES: Record<AccentPalette, AccentIdentity> = {
  blue: { hue: 263, chroma: 0.215 },
  green: { hue: 153, chroma: 0.155 },
  // Pale amber starts yellow, then transitions into its orange pigment by 400. Its chroma eases into
  // the vivid middle range instead of jumping from pale 200 to 300.
  amber: { hue: 65, chroma: 0.24, paleHue: { hue: 90, from: "200", to: "400" }, chromaRatio: { "200": 0.44, "300": 0.55 } },
  red: { hue: 25, chroma: 0.215 },
};

// The neutral steps that sit between two authored anchors: [from, to, how far toward `to`].
export const NEUTRAL_BETWEEN = {
  "150": ["100", "200", 0.5],
  "650": ["600", "700", 0.5],
  "875": ["800", "900", 0.75],
  "925": ["900", "950", 0.5],
} as const satisfies Record<Exclude<PaletteStep, NeutralBaseStep>, readonly [NeutralBaseStep, NeutralBaseStep, number]>;

const neutralBaseRamp = completeOklchRamp(NEUTRAL_BASE_STEPS, NEUTRAL_ANCHORS);
const neutral: Record<PaletteStep, Oklch> = Object.fromEntries(PALETTE_STEPS.map((step) => {
  if (!(step in NEUTRAL_BETWEEN)) return [step, neutralBaseRamp[step as NeutralBaseStep]];
  const [from, to, weight] = NEUTRAL_BETWEEN[step as keyof typeof NEUTRAL_BETWEEN];
  return [step, interpolateOklch(neutralBaseRamp[from], neutralBaseRamp[to], weight)];
})) as Record<PaletteStep, Oklch>;

const clamp01 = (value: number) => Math.max(0, Math.min(1, value));

const accent = Object.fromEntries(ACCENT_PALETTES.map((name) => [
  name,
  Object.fromEntries(ACCENT_STEPS.map((step) => {
    const [lightness, curveRatio] = ACCENT_CURVE[step];
    const { hue, chroma, paleHue, chromaRatio } = ACCENT_IDENTITIES[name];
    const rampHue = paleHue
      ? paleHue.hue - (paleHue.hue - hue) * clamp01((Number(step) - Number(paleHue.from)) / (Number(paleHue.to) - Number(paleHue.from)))
      : hue;
    return [step, [lightness, chroma * (chromaRatio?.[step] ?? curveRatio), rampHue] as Oklch];
  })) as Record<AccentStep, Oklch>,
])) as Record<AccentPalette, Record<AccentStep, Oklch>>;

// Complete theme-independent OKLCH palette. Semantic systems select from these coordinates' HEX
// companions; changing the active theme never changes this source ramp.
// The highlighter: one pigment and no ramp, because it is laid behind text and never becomes a surface or a state.
const MARKER: Oklch = [0.962, 0.187, 113];

export const OKLCH_PALETTE = { neutral, accent, marker: MARKER };

type NeutralPalette = Record<PaletteStep, PaletteToken>;
type AccentRamp = Record<AccentStep, PaletteToken>;
type AlphaPalette = Record<`alpha${AlphaStep}`, { neutral: { "0": PaletteToken; "950": PaletteToken } }>;

const neutralTokens = Object.fromEntries(PALETTE_STEPS.map((step) => [step, toPaletteToken(neutral[step])])) as NeutralPalette;
const accentTokens = Object.fromEntries(ACCENT_PALETTES.map((name) => [
  name,
  Object.fromEntries(ACCENT_STEPS.map((step) => [step, toPaletteToken(accent[name][step])])) as AccentRamp,
])) as Record<AccentPalette, AccentRamp>;
const alphaTokens = Object.fromEntries(ALPHA_STEPS.map((step) => [`alpha${step}`, {
  neutral: {
    "0": withAlpha(neutralTokens["0"], ALPHA_OPACITY[step]),
    "950": withAlpha(neutralTokens["950"], ALPHA_OPACITY[step]),
  },
}])) as AlphaPalette;

export const PALETTE_TOKENS = { neutral: neutralTokens, accent: accentTokens, marker: toPaletteToken(MARKER), ...alphaTokens };
